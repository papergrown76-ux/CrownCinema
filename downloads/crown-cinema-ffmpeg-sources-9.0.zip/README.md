Exact FFmpeg/library sources for CrownCinema. See third-party/ffmpeg/README.md.
Build: python3 tools/build-bundled-ffmpeg.py (Linux x86-64).
Place source archives from sources/ into .deps/ffmpeg/archives/ for offline source reuse.
The pinned Zig compiler is downloaded separately and checksum verified.
